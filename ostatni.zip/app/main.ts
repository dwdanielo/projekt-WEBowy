import { bootstrap }    from 'angular2/platform/browser';
import { ContactList } from './contact-list';
import { ContactStore } from './contact-store';

bootstrap(ContactList, [ContactStore]);