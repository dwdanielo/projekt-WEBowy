System.config({
  //use typescript for compilation
  transpiler: 'typescript',
  //typescript compiler options
  typescriptOptions: {
    emitDecoratorMetadata: true
  },
  //map tells the System loader where to look for things
  map: {
    app: "./app",
    'redux': 'https://cdnjs.cloudflare.com/ajax/libs/redux/3.5.2/redux.js',
    'immutable': 'https://cdnjs.cloudflare.com/ajax/libs/immutable/3.8.1/immutable.js'
  },
  //packages defines our app package
  packages: {
    app: {
      main: './main.ts',
      defaultExtension: 'ts'
    }
  }
});